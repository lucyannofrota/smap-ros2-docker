Packaging for URG Helper / URG Widget / URG Library / urg_c

Original Source at:
http://sourceforge.net/projects/urgwidget

This project introduces sample programs of the URG library. Applications using URG and URG library are also introduced here. URG is Scanning Laser Range Finder of Hokuyo Automatic Co., for robots, autonomous systems and security systems.
